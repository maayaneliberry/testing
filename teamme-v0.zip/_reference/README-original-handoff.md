# TeamMe — Hebrew landing page (developer handoff)

Landing page for TeamMe, aimed at Israeli government companies, banks and defense companies.
Language: Hebrew, right-to-left (`<html lang="he" dir="rtl">`).

## Links

- Design canvas (Claude Design): https://claude.ai/artifact/QrSJbUgUaqZjSFryz37pKE
  The link is private until the owner shares it from the canvas's Share menu.
- Fonts (Google Fonts): https://fonts.google.com/specimen/Heebo · https://fonts.google.com/specimen/Karantina

## What's in this folder

| Path | What it is |
|---|---|
| `index.html` | **The page.** A self-contained static HTML file that opens directly in a browser. All styles are inline, and assets load from `assets/` by relative path. The layout is fluid: it uses flex-wrap and grid, so it already stacks at narrow widths. |
| `mobile-reference/mobile-1..3.html` | The mobile design (390px wide), split into three parts because of a frame-height limit in the design tool. Treat it as the **visual reference** for small screens: its spacing, type sizes and stacking should become media queries on the real page. |
| `source-claude-design/` | The original design-tool source files (`*.dc.html` plus `canvas.json`). Asset URLs there are `/_blob/<id>` links into the design tool. Kept for reference only. |
| `assets/images/` | TeamMe logo (cropped for the header; the original is also included) and the team photo. |
| `assets/logos/` | Client logos: Israel Railways, Discount Bank, Yad2, monday.com, NICE, Palo Alto Networks. |
| `assets/videos/` | Web-compressed videos used on the page (540×960 H.264, about 11 MB each) plus poster images. |
| `assets/videos/originals/` | Full-quality source videos (4K / 1080p, 80 MB and 142 MB). Use these to produce production encodes. |

**Database:** none. The page stores no data and has no backend. The contact form is markup only (see the to-do list).

## Page sections (top to bottom)

1. Header: logo, nav anchors (`#why`, `#pillars`, `#sectors`), "צור קשר" button that goes to `#contact`.
2. Hero (`#top`): headline "האנשים שלכם הם הכוח המניע.", subline, two buttons, and a vertical video (`hero-israel-railways.mp4`) with a decorative "פניות מועמדים" card.
3. Client logos strip.
4. People-First intro, with the team photo.
5. Netflix-style candidate experience (`#experience`), with a phone frame and video (`experience-anat.mp4`).
6. Why TeamMe (`#why`): four feature cards.
7. Auto Pilot / Single Source of Truth (`#ssot`): ATS → TeamMe → all recruiting channels.
8. Steering wheel / full control (`#control`), including the "careers page is asset #2" highlight.
9. Who it's for (`#sectors`): government and infrastructure, banking and finance, defense and government suppliers.
10. The 4 channels (`#pillars`): four cards.
11. What the organization gets: four tiles.
12. CTA and contact form (`#contact`).
13. Footer.

## Design tokens

| Token | Value | Use |
|---|---|---|
| Purple 900 | `#1F1147` | Dark sections (experience, pillars) |
| Purple 800 | `#2B1A60` | Cards on dark |
| Purple 700 | `#3B1F86` | Primary button, icon tiles, highlight boxes |
| Purple 500 | `#6A35D4` | Eyebrows, accent words |
| Purple 50 | `#F6F3FD` | Light section backgrounds |
| Yellow | `#F5B91A` | Main CTA, accents (matches the dot in the logo) |
| Ink | `#1C1530` | Body text |
| Muted text | `#4A4360` / `#6B6385` | Secondary text |
| Border | `#ECE8F5` / `#E6DEFA` | Dividers, outlines |
| Hero gradient | `linear-gradient(135deg, #6A35D4 0%, #3A1F86 32%, #26145A 58%, #4A1D86 80%, #8E2BB8 100%)` | Hero |
| CTA gradient | `linear-gradient(135deg, #3A1F86 0%, #26145A 55%, #7A26A8 100%)` | Contact section |

- Fonts: **Karantina 700** for display headlines and big numbers, and **Heebo** 400–900 for everything else.
- Radii: 999px for pills and buttons, 16–28px for cards. Content max-width is 1200px.

## To-do for production

- [ ] **Contact form:** connect it to a backend or CRM, or replace it with a booking link. Add validation, success and error states, consent text, and spam protection. Fields: full name, organization, role, phone, email.
- [ ] **Responsive:** turn `mobile-reference/` into media queries. Desktop section padding is 104px and mobile is 64px; headline sizes and grids differ too.
- [ ] **Videos:** produce final encodes from `originals/`: H.264 MP4 at 720×1280 or 1080×1920, ideally with an adaptive or CDN option. Keep `muted autoplay loop playsinline` and a poster image. Consider lazy-loading the second video.
- [ ] **Footer links:** "הצהרת נגישות" (accessibility statement) and "מדיניות פרטיות" (privacy policy) currently point to `#`.
- [ ] **Analytics and tracking:** add pixels and events (CTA clicks, form submit, video plays).
- [ ] **SEO:** title and meta description are set in `index.html`; add Open Graph tags, a favicon, and structured data if needed.
- [ ] **Accessibility:** this audience may expect compliance with the Israeli accessibility standard (ת״י 5568, WCAG 2.0 AA). Run an audit before launch.

## Asset sources and permissions

- **TeamMe logo, team photo, both videos:** supplied by TeamMe.
- **Client logos:** downloaded from Wikimedia (Israel Railways, monday.com, NICE and Palo Alto Networks from Wikimedia Commons; Yad2 from Hebrew Wikipedia, where it's a non-free file). The Discount Bank logo was supplied by TeamMe. All are trademarks of their owners; confirm each client has approved its logo before going live.
- **Team photo:** shows real people. Confirm their consent for public use.
