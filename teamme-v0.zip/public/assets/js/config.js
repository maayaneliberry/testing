/* ==========================================================================
   TeamMe landing page — settings
   ========================================================================== */
window.TEAMME_CONFIG = {
  // Where the contact form posts. The serverless function in api/contact.js
  // sends each lead by email through Resend (see README → "Contact form").
  contactEndpoint: "/api/contact",

  // Google Tag Manager container ID, e.g. "GTM-ABC1234".
  // Leave empty to load no tracking at all. Events are still collected in
  // window.dataLayer, so they start flowing the moment an ID is added.
  gtmId: ""
};
