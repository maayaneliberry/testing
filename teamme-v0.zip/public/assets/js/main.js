/* ==========================================================================
   TeamMe landing page — behaviour
   1. Analytics events (dataLayer) + optional Google Tag Manager
   2. Video players: pause/play, sound, lazy-load, reduced motion
   3. Contact form: validation, spam protection, send via /api/contact (Resend), states
   ========================================================================== */
(function () {
  "use strict";

  var CONFIG = window.TEAMME_CONFIG || {};
  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ------------------------------------------------------------------------
     1. Analytics
     Every interaction is pushed to window.dataLayer. With a GTM ID in
     config.js, GTM picks these up; without one, nothing leaves the browser.
     Events: cta_click, video_play, video_pause, video_unmute,
             form_start, form_submit, form_success, form_error
     ------------------------------------------------------------------------ */
  window.dataLayer = window.dataLayer || [];
  function track(event, params) {
    var payload = { event: event };
    if (params) for (var k in params) payload[k] = params[k];
    window.dataLayer.push(payload);
  }

  if (CONFIG.gtmId && /^GTM-[A-Z0-9]+$/.test(CONFIG.gtmId)) {
    window.dataLayer.push({ "gtm.start": new Date().getTime(), event: "gtm.js" });
    var gtm = document.createElement("script");
    gtm.async = true;
    gtm.src = "https://www.googletagmanager.com/gtm.js?id=" + CONFIG.gtmId;
    document.head.appendChild(gtm);
  }

  document.addEventListener("click", function (e) {
    var el = e.target.closest && e.target.closest("[data-cta]");
    if (!el) return;
    track("cta_click", {
      cta_label: el.getAttribute("data-cta"),
      cta_location: el.getAttribute("data-cta-location") || "",
      cta_target: el.getAttribute("href") || ""
    });
  });

  /* ------------------------------------------------------------------------
     2. Video players
     Markup: .video > video + .video__controls > [data-action=toggle|sound]
     A <video data-src="..."> is loaded only when it nears the viewport.
     Videos pause when scrolled out of view and resume when back (unless the
     visitor paused them). With "reduce motion" on, nothing autoplays.
     ------------------------------------------------------------------------ */
  var players = [];

  function setupPlayer(wrap) {
    var video = wrap.querySelector("video");
    var toggleBtn = wrap.querySelector('[data-action="toggle"]');
    var soundBtn = wrap.querySelector('[data-action="sound"]');
    var name = wrap.getAttribute("data-video-name") || "video";
    var state = { userPaused: reduceMotion, loaded: !video.getAttribute("data-src"), visible: false };

    function syncUI() {
      var paused = video.paused;
      wrap.classList.toggle("is-paused", paused);
      toggleBtn.setAttribute("aria-label", paused ? "הפעלת הסרטון" : "השהיית הסרטון");
      var unmuted = !video.muted;
      wrap.classList.toggle("is-unmuted", unmuted);
      soundBtn.setAttribute("aria-label", unmuted ? "השתקת הסרטון" : "הפעלת הסאונד");
      soundBtn.setAttribute("aria-pressed", unmuted ? "true" : "false");
    }

    function load() {
      if (state.loaded) return;
      video.src = video.getAttribute("data-src");
      video.removeAttribute("data-src");
      state.loaded = true;
    }

    function play() {
      load();
      var p = video.play();
      if (p && p.catch) p.catch(function () { syncUI(); });
    }

    toggleBtn.addEventListener("click", function () {
      if (video.paused) {
        state.userPaused = false;
        play();
        track("video_play", { video_name: name });
      } else {
        state.userPaused = true;
        video.pause();
        track("video_pause", { video_name: name });
      }
    });

    soundBtn.addEventListener("click", function () {
      var willUnmute = video.muted;
      if (willUnmute) {
        // only one video talks at a time
        players.forEach(function (other) { if (other.video !== video) { other.video.muted = true; other.syncUI(); } });
        video.muted = false;
        state.userPaused = false;
        if (video.paused) play();
        track("video_unmute", { video_name: name });
      } else {
        video.muted = true;
      }
      syncUI();
    });

    ["play", "pause", "volumechange"].forEach(function (ev) { video.addEventListener(ev, syncUI); });

    if (reduceMotion) {
      video.removeAttribute("autoplay");
      video.pause();
    }

    if ("IntersectionObserver" in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          state.visible = entry.isIntersecting;
          if (entry.isIntersecting) {
            load();
            if (!state.userPaused && video.paused) play();
          } else if (!video.paused) {
            video.pause();
          }
        });
      }, { rootMargin: "200px 0px" });
      io.observe(wrap);
    } else {
      load();
      if (!state.userPaused) play();
    }

    syncUI();
    players.push({ video: video, syncUI: syncUI });
  }

  document.querySelectorAll(".video").forEach(setupPlayer);

  /* ------------------------------------------------------------------------
     3. Contact form
     ------------------------------------------------------------------------ */
  var form = document.getElementById("contact-form");
  if (form) setupForm(form);

  function setupForm(form) {
    var ENDPOINT = CONFIG.contactEndpoint || "/api/contact";
    var startedAt = Date.now();
    var attempted = false;
    var started = false;
    var submitBtn = form.querySelector('button[type="submit"]');
    var submitLabel = submitBtn.innerHTML;
    var status = form.querySelector(".form__status");
    var successBox = document.getElementById("form-success");

    // Keep UTM parameters from the landing URL so leads show their campaign.
    var UTM_KEYS = ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "gclid", "fbclid", "li_fat_id"];
    var utm = {};
    try {
      var params = new URLSearchParams(window.location.search);
      var stored = JSON.parse(sessionStorage.getItem("teamme_utm") || "{}");
      UTM_KEYS.forEach(function (k) { var v = params.get(k) || stored[k]; if (v) utm[k] = v; });
      sessionStorage.setItem("teamme_utm", JSON.stringify(utm));
    } catch (err) { /* storage blocked — fine */ }

    var rules = {
      name: { test: function (v) { return v.trim().length >= 2; }, msg: "נא למלא שם מלא" },
      organization: { test: function (v) { return v.trim().length >= 2; }, msg: "נא למלא את שם הארגון" },
      phone: { test: function (v) { var d = v.replace(/\D/g, ""); return d.length >= 9 && d.length <= 15; }, msg: "נא למלא מספר טלפון תקין" },
      email: { test: function (v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()); }, msg: "נא למלא כתובת אימייל תקינה" }
    };

    function validateField(input) {
      var rule = rules[input.name];
      if (!rule) return true;
      var ok = rule.test(input.value);
      var err = document.getElementById(input.id + "-error");
      input.setAttribute("aria-invalid", ok ? "false" : "true");
      if (err) err.textContent = ok ? "" : rule.msg;
      return ok;
    }

    Object.keys(rules).forEach(function (n) {
      var input = form.elements[n];
      input.addEventListener("blur", function () { if (attempted || input.value) validateField(input); });
      input.addEventListener("input", function () { if (input.getAttribute("aria-invalid") === "true") validateField(input); });
    });

    form.addEventListener("focusin", function () {
      if (started) return;
      started = true;
      track("form_start", { form_name: "contact" });
    });

    function setLoading(on) {
      submitBtn.disabled = on;
      submitBtn.innerHTML = on ? '<span class="spinner" aria-hidden="true"></span>שולח…' : submitLabel;
    }

    function showError(msg) {
      status.className = "form__status form__status--error";
      status.textContent = msg;
    }

    function showSuccess() {
      form.hidden = true;
      successBox.hidden = false;
      successBox.focus();
    }

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      attempted = true;
      status.textContent = "";
      status.className = "form__status";

      var firstInvalid = null;
      Object.keys(rules).forEach(function (n) {
        var input = form.elements[n];
        if (!validateField(input) && !firstInvalid) firstInvalid = input;
      });
      if (firstInvalid) { firstInvalid.focus(); return; }

      track("form_submit", { form_name: "contact" });

      // Spam: hidden honeypot ticked, or submitted faster than a human could.
      // The server checks both again.
      var elapsed = Date.now() - startedAt;
      if (form.elements.botcheck.checked || elapsed < 2500) { showSuccess(); return; }

      var payload = {
        name: form.elements.name.value.trim(),
        organization: form.elements.organization.value.trim(),
        role: form.elements.role.value.trim(),
        phone: form.elements.phone.value.trim(),
        email: form.elements.email.value.trim(),
        marketing: form.elements.marketing.checked,
        page: window.location.href.split("?")[0],
        utm: utm,
        botcheck: false,
        elapsedMs: elapsed
      };

      setLoading(true);
      fetch(ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(payload)
      })
        .then(function (res) { return res.json().catch(function () { return { ok: false, error: "http_" + res.status }; }); })
        .then(function (json) {
          if (json && json.ok) {
            track("form_success", { form_name: "contact" });
            form.reset();
            showSuccess();
          } else {
            throw new Error((json && (json.message || (json.body && json.body.message))) || "submit_failed");
          }
        })
        .catch(function (err) {
          track("form_error", { form_name: "contact", error: String(err && err.message || err) });
          showError("משהו השתבש בשליחה. נסו שוב בעוד רגע.");
        })
        .then(function () { setLoading(false); });
    });
  }

  /* ------------------------------------------------------------------------
     4. Header over the hero + hero scroll effect
     The header is clear glass over the photo and turns to cream glass once
     the hero scrolls away. While scrolling, the photo drifts and zooms a
     little and the hero text fades (skipped with "reduce motion").
     ------------------------------------------------------------------------ */
  var header = document.querySelector("[data-header]");
  var hero = document.querySelector("[data-hero]");
  if (header && hero) {
    var ticking = false;
    var update = function () {
      ticking = false;
      var h = hero.offsetHeight || 1;
      var y = window.scrollY || window.pageYOffset;
      header.classList.toggle("is-solid", y > h - header.offsetHeight - 8);
      if (!reduceMotion) hero.style.setProperty("--hero-p", Math.min(1, Math.max(0, y / h)).toFixed(3));
    };
    window.addEventListener("scroll", function () {
      if (!ticking) { ticking = true; window.requestAnimationFrame(update); }
    }, { passive: true });
    window.addEventListener("resize", update);
    update();
  }

  /* Footer year */
  var y = document.querySelector("[data-year]");
  if (y) y.textContent = new Date().getFullYear();
})();
