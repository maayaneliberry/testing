# TeamMe — Hebrew landing page (production build)

Landing page for TeamMe, aimed at Israeli government companies, banks and defense companies.
Hebrew, right-to-left. The page itself is plain HTML/CSS/JS in `public/`. A minimal Next.js wrapper serves it and adds one server route, `/api/contact`, that emails form leads through Resend. Works in v0 and on Vercel as-is. No database.

Design canvas (Claude Design): https://claude.ai/artifact/QrSJbUgUaqZjSFryz37pKE

## Before going live (2 steps)

1. **Contact form → Resend.** Add these environment variables (in v0: the chat's Settings → Vars; on Vercel: Project → Settings → Environment Variables), then redeploy:
   - `RESEND_API_KEY` (required): a Resend API key with sending access.
   - `CONTACT_TO` (optional): who gets leads. Default `maayan@teamme.io`. Comma-separate for several.
   - `CONTACT_FROM` (optional): sender. Default `TeamMe Website <website@teamme.io>`, which works only if `teamme.io` is a verified domain in Resend. For a quick test without a verified domain use `TeamMe <onboarding@resend.dev>`; Resend then delivers only to the email of the Resend account owner.

   Each lead arrives as a Hebrew email with all fields, the campaign (UTM) data, and Reply-To set to the lead, so replying answers them directly. Without `RESEND_API_KEY` the form shows an error and nothing is sent.
2. **Set the domain.** Replace `SITE_URL` with the real domain in `public/index.html`, `public/accessibility.html`, `public/privacy.html`, `public/robots.txt` and `public/sitemap.xml`. This makes WhatsApp/LinkedIn previews and SEO work.

The accessibility statement and privacy policy are finished, general versions with `team@teamme.io` as the contact. A review by a lawyer / accessibility consultant is still a good idea.

Optional: add a Google Tag Manager ID in `public/assets/js/config.js` (`gtmId`) to turn on analytics.

## Deploy

Standard Next.js project: `npm install`, then `npm run dev` locally or deploy to Vercel / publish from v0. `next.config.mjs` rewrites `/` to `public/index.html` and adds caching and basic security headers. For local form tests copy `.env.example` to `.env.local` and add your key.

## Files

| Path | What it is |
|---|---|
| `public/index.html` | The landing page. |
| `public/accessibility.html` | Accessibility statement (הצהרת נגישות). |
| `public/privacy.html` | Privacy policy (מדיניות פרטיות). |
| `public/assets/css/styles.css` | All styles. Design tokens at the top, responsive rules at the bottom (≤1024px tablet, ≤640px mobile from `_reference/mobile-reference`, ≤360px small phones). |
| `app/api/contact/route.js` | Server route: validates the lead, drops spam (honeypot + time trap, checked again on the server), sends the email through the Resend API. The API key never reaches the browser. |
| `public/assets/js/config.js` | Settings: form endpoint (`/api/contact`) and GTM ID. |
| `public/assets/js/main.js` | Analytics events, video players, contact form. |
| `public/assets/fonts/` | Google Sans (variable 400–700, Hebrew + Latin) from Google Fonts, self-hosted as woff2 so the page makes no request to Google (SIL OFL license included). |
| `public/assets/videos/` | 720×1280 H.264 encodes made from the 4K/1080p originals (~5.8 MB each, faststart) + JPG posters from the original cover frames. |
| `public/assets/images/` | TeamMe logo (`teamme-logo.svg` dark, `teamme-logo-cream.svg` for dark backgrounds, traced from the supplied black PNG; the PNG is kept for structured data), Discount Bank hero photo and campus team-walk photo (each 800/1200/2000px WebP), `og-image.jpg` (1200×630 share image), favicons. |
| `public/assets/logos/` | Client logos (SVG; Discount Bank as WebP, plus a white transparent PNG for the hero credit). Bank Hapoalim: the 2018 Hebrew logo from Wikimedia Commons (`File:Bank hapoalim logo heb18.svg`, marked public domain there). |
| `public/favicon.ico`, `public/robots.txt`, `public/sitemap.xml` | Standard site files. |
| `next.config.mjs`, `package.json` | Next.js setup: serves the static page, headers, the one API route. |
| `_reference/` | Design-tool source and the 390px mobile frames. Not part of the site. |

## Visual style

Cream "Stealth to loud" system, shared with the TeamMe launch-offer page: cream paper `#F2ECE1`, tinted bands `#EDE6D9`, cards `#FBF8F2`, ink `#141414`, signal orange `#E2471B` (`#B8360F` for small orange text). Bold Google Sans headlines, uppercase labels for English tags, dark ink bands for the candidate-experience story and the contact close. **Hero:** full-screen Discount Bank campus photo with the headline on the image, a frosted-glass header that turns cream after the hero, frosted buttons and a frosted "Discount · פרויקט מיתוג מעסיק" credit chip. Load animation (photo settles, text rises) and a light scroll effect (photo drifts, text fades), both off when the visitor has "reduce motion" on. The Israel Railways and Anat videos sit side by side in the Netflix-experience section. All tokens are at the top of `styles.css`.

## What changed from the design handoff

- **Responsive:** inline styles moved into `styles.css` so media queries work. Fixed the horizontal scroll on phones (the 4-channels grid was forcing 440px). Verified with no overflow at 360, 390, 768 and 1440px.
- **Contact form:** required-field validation in Hebrew (name, organization, phone, email; role optional), errors linked to fields for screen readers, loading / success / error states, optional marketing opt-in (unchecked by default), privacy note, honeypot + time-trap spam protection, UTM/click-ID capture sent with each lead. Posts JSON to `/api/contact`, which emails the lead via Resend.
- **Videos:** re-encoded from originals at 720p (half the size of the old 540p files). Native browser controls replaced with pause/play and sound buttons. Only one video plays sound at a time. Second video loads only when scrolled near. Videos pause off-screen. No autoplay when the OS "reduce motion" setting is on.
- **SEO & sharing:** Open Graph + Twitter tags, share image, favicons, canonical URL, Organization structured data, robots.txt, sitemap.xml.
- **Analytics:** events pushed to `window.dataLayer` (see below). GTM loads only if an ID is set.
- **Accessibility:** skip link, `<main>` landmark, visible focus rings, proper heading order, `lang="en"` on English phrases, explicit image sizes (no layout shift). axe-core (WCAG 2.0/2.1 A + AA + best practices): 0 violations on all three pages at mobile and desktop widths. A manual audit by an accessibility consultant is still recommended for ת״י 5568.
- **Footer:** links now go to the accessibility statement and privacy policy.

Copy is unchanged. Note: `_reference/mobile-reference/mobile-3.html` titles channel 03 "הקמה וניהול ערוצים ארגוניים", while the desktop design (used here) says "הקמה וניהול ערוצי מדיה".

## Analytics events (`window.dataLayer`)

| Event | When | Params |
|---|---|---|
| `cta_click` | Any element with `data-cta` is clicked | `cta_label`, `cta_location`, `cta_target` |
| `video_play` / `video_pause` | Visitor uses the play/pause button | `video_name` |
| `video_unmute` | Visitor turns sound on | `video_name` |
| `form_start` | First focus inside the form | `form_name` |
| `form_submit` | Valid form submitted | `form_name` |
| `form_success` / `form_error` | `/api/contact` response | `form_name`, `error` |

If analytics or marketing pixels are added through GTM, update the cookies paragraph in `privacy.html` and check whether a consent banner is needed.

## Still open

- **Permissions:** confirm each client approved its logo, and that people in the photos and videos consented to public use.

## Asset sources and permissions (from the design handoff)

- TeamMe logo, Discount Bank photos, both videos: supplied by TeamMe.
- Client logos: Israel Railways, monday.com, NICE and Palo Alto Networks from Wikimedia Commons; Yad2 from Hebrew Wikipedia (non-free file); Discount Bank supplied by TeamMe; Bank Hapoalim from Wikimedia Commons. All are trademarks of their owners; confirm each client has approved its logo before going live.
- Full-quality source videos (`ANAT_final.mp4`, `ATAT_FINAL_PIC_WITH_COVER.mp4`) are in the original handoff zip, not in this package.
