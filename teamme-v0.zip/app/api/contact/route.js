/* ==========================================================================
   POST /api/contact — sends a landing-page lead by email through Resend.

   Environment variables (Vercel / v0 → Settings → Environment Variables):
     RESEND_API_KEY  required  Your Resend API key (starts with "re_").
     CONTACT_TO      optional  Who receives leads. Comma-separate for several.
                               Default: maayan@teamme.io
     CONTACT_FROM    optional  Sender. Must be on a domain verified in Resend.
                               Default: TeamMe Website <website@teamme.io>
   The API key stays on the server; the browser never sees it.
   ========================================================================== */

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const RESEND_URL = "https://api.resend.com/emails";
const DEFAULT_TO = "maayan@teamme.io";
const DEFAULT_FROM = "TeamMe Website <website@teamme.io>";

const LIMITS = { name: 120, organization: 160, role: 120, phone: 40, email: 200, page: 300 };
const UTM_KEYS = ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "gclid", "fbclid", "li_fat_id"];

function clean(value, max) {
  return String(value == null ? "" : value).replace(/[\u0000-\u001F\u007F]/g, " ").trim().slice(0, max);
}

function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function validate(f) {
  const bad = [];
  if (f.name.length < 2) bad.push("name");
  if (f.organization.length < 2) bad.push("organization");
  const digits = f.phone.replace(/\D/g, "");
  if (digits.length < 9 || digits.length > 15) bad.push("phone");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email)) bad.push("email");
  return bad;
}

function buildEmail(f, marketing, utm) {
  const rows = [
    ["שם מלא", f.name],
    ["ארגון", f.organization],
    ["תפקיד", f.role || "—"],
    ["טלפון", f.phone],
    ["אימייל", f.email],
    ["הסכמה לדיוור", marketing ? "כן" : "לא"],
    ["עמוד", f.page || "—"]
  ].concat(Object.keys(utm).map((k) => [k, utm[k]]));

  const html =
    '<div dir="rtl" style="font-family:Arial,Helvetica,sans-serif;font-size:15px;color:#141414;line-height:1.5">' +
    '<h2 style="margin:0 0 16px;font-size:20px">פנייה חדשה מדף הנחיתה</h2>' +
    '<table cellpadding="8" cellspacing="0" style="border-collapse:collapse;border:1px solid #E0D7C6">' +
    rows.map(([k, v]) =>
      '<tr><td style="background:#F2ECE1;font-weight:bold;border:1px solid #E0D7C6;white-space:nowrap">' + escapeHtml(k) +
      '</td><td style="border:1px solid #E0D7C6">' + escapeHtml(String(v)) + "</td></tr>"
    ).join("") +
    "</table>" +
    '<p style="margin:16px 0 0;color:#5B564D;font-size:13px">אפשר להשיב למייל הזה ישירות כדי לענות לפונה.</p>' +
    "</div>";

  const text = rows.map(([k, v]) => k + ": " + v).join("\n");
  return { html, text };
}

const json = (body, status = 200) => Response.json(body, { status });

export async function POST(request) {
  let body = null;
  try { body = await request.json(); } catch (e) { body = null; }
  if (!body || typeof body !== "object") return json({ ok: false, error: "bad_request" }, 400);

  // Spam: honeypot ticked, or sent faster than a person can fill the form.
  // Answer "ok" so bots learn nothing; nothing is sent.
  const elapsed = Number(body.elapsedMs);
  if (body.botcheck || (Number.isFinite(elapsed) && elapsed >= 0 && elapsed < 2500)) {
    return json({ ok: true });
  }

  const f = {};
  Object.keys(LIMITS).forEach((k) => { f[k] = clean(body[k], LIMITS[k]); });
  const invalid = validate(f);
  if (invalid.length) return json({ ok: false, error: "invalid", fields: invalid }, 400);

  const utm = {};
  const rawUtm = body.utm && typeof body.utm === "object" ? body.utm : {};
  UTM_KEYS.forEach((k) => { if (rawUtm[k]) utm[k] = clean(rawUtm[k], 200); });

  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.error("[contact] RESEND_API_KEY is not set");
    return json({ ok: false, error: "not_configured" }, 500);
  }
  const to = (process.env.CONTACT_TO || DEFAULT_TO).split(",").map((s) => s.trim()).filter(Boolean);
  const from = process.env.CONTACT_FROM || DEFAULT_FROM;
  const { html, text } = buildEmail(f, Boolean(body.marketing), utm);

  try {
    const r = await fetch(RESEND_URL, {
      method: "POST",
      headers: { Authorization: "Bearer " + apiKey, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to,
        reply_to: f.email,
        subject: "פנייה חדשה מדף הנחיתה — " + f.organization,
        html,
        text
      })
    });
    if (!r.ok) {
      const detail = await r.text().catch(() => "");
      console.error("[contact] Resend error", r.status, detail.slice(0, 500));
      return json({ ok: false, error: "send_failed" }, 502);
    }
    return json({ ok: true });
  } catch (err) {
    console.error("[contact] Resend request failed", err);
    return json({ ok: false, error: "send_failed" }, 502);
  }
}
